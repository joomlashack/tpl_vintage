<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted index access' );
?>
<?php
echo "<a href=\"http://www.joomlashack.com\" title=\"Joomla 1.5 Templates\">Joomla Templates by Joomlashack</a>";
?>